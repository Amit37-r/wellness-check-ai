// server/index.js
import express from 'express';
import fetch from 'node-fetch';
import cors from 'cors';
import dotenv from 'dotenv';

dotenv.config();

const app = express();
app.use(cors());
app.use(express.json({ limit: '200kb' }));

const PORT = process.env.PORT || 5174;
const OPENAI_KEY = process.env.OPENAI_API_KEY || '';
const MOCK_AI = (process.env.MOCK_AI || 'true').toLowerCase() === 'true';

// ---- Helpers ----

function safeParseJSON(maybe) {
  if (!maybe || typeof maybe !== 'string') return null;
  maybe = maybe.trim();
  try {
    if (maybe[0] === '{' || maybe[0] === '[') return JSON.parse(maybe);
    const first = Math.min(...['{', '['].map(c => { const i = maybe.indexOf(c); return i === -1 ? Infinity : i; }));
    if (first !== Infinity) {
      const sub = maybe.slice(first);
      return JSON.parse(sub);
    }
  } catch (e) {
    return null;
  }
  return null;
}

async function callOpenAIChat(messages, maxTokens = 500, temperature = 0.7) {
  if (!OPENAI_KEY) throw new Error('OPENAI_API_KEY not set on server');

  // Chat completions endpoint
  const payload = {
    model: 'gpt-4o-mini', // or another model you prefer
    messages,
    max_tokens: maxTokens,
    temperature
  };

  const resp = await fetch('https://api.openai.com/v1/chat/completions', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${OPENAI_KEY}`
    },
    body: JSON.stringify(payload)
  });

  const text = await resp.text();
  if (!resp.ok) {
    throw new Error(`OpenAI API error: ${resp.status} ${text}`);
  }

  // parse JSON body
  try {
    const json = JSON.parse(text);
    const content = json.choices?.[0]?.message?.content || '';
    return content;
  } catch (err) {
    // if we can't parse the outer response, return raw text
    return text;
  }
}

// ---- Mock helpers (kept for fallback) ----
function mockGenerate(profile) {
  const base = [
    { title: 'Brisk walk', icon: '🚶', summary: '20 minutes walk daily' },
    { title: 'Hydrate', icon: '💧', summary: 'Aim for 8 cups of water' },
    { title: 'Protein meals', icon: '🥗', summary: 'Include lean protein in meals' },
    { title: 'Sleep routine', icon: '🛌', summary: 'Keep consistent sleep and wake times' },
    { title: 'Mindful breaks', icon: '🧘', summary: 'Do 3 short breathing breaks daily' }
  ];
  return base.map((b, i) => ({ id: `mock-${i + 1}`, ...b }));
}

function mockExpand(tip, profile) {
  const title = tip?.title || 'Tip';
  const details = `Detailed steps for "${title}":\n1) Warm-up 3-5 mins\n2) Do main activity for 15-30 mins\n3) Cool down.\nPersonalization: goal=${profile?.goal || 'n/a'}, age=${profile?.age || 'n/a'}`;
  return { id: tip?.id || null, details };
}

// ---- Endpoints ----

// Generate tips
app.post('/api/generate-tips', async (req, res) => {
  try {
    const { profile } = req.body;
    if (!profile || typeof profile !== 'object') {
      return res.status(400).json({ ok: false, error: 'profile (object) is required in body' });
    }

    if (MOCK_AI) {
      return res.json({ ok: true, tips: mockGenerate(profile) });
    }

    // Ask the model to return clean JSON array of tips
    const prompt = `
You are an assistant that generates 5 concise wellness tips tailored to the user.
Return ONLY a JSON array (no commentary) containing objects with keys:
"id", "title", "icon", "summary".
Make sure "id" values are short unique strings (e.g. "tip-1").
User profile: ${JSON.stringify(profile)}
`;

    const content = await callOpenAIChat([{ role: 'user', content: prompt }], 500, 0.7);
    // try to parse JSON
    const parsed = safeParseJSON(content);
    if (parsed && Array.isArray(parsed)) {
      // ensure ids
      const now = Date.now();
      const tips = parsed.map((t, i) => ({ id: t.id || `tip-${now}-${i}`, title: t.title || '', icon: t.icon || '', summary: t.summary || '' }));
      return res.json({ ok: true, tips });
    }

    // fallback: return raw text so frontend may try to parse
    return res.json({ ok: true, tips_raw: content });
  } catch (err) {
    console.error('generate-tips error:', err);
    return res.status(500).json({ ok: false, error: err.message || 'server error' });
  }
});

// Expand a single tip into details (returns id + details)
app.post('/api/expand-tip', async (req, res) => {
  try {
    const { tip, profile } = req.body;
    if (!tip || typeof tip !== 'object') {
      return res.status(400).json({ ok: false, error: 'tip (object) is required in body' });
    }
    const tipId = tip.id || null;

    if (MOCK_AI) {
      const expanded = mockExpand(tip, profile);
      return res.json({ ok: true, id: tipId, details: expanded.details || '' });
    }

    const prompt = `
Expand the following tip into a short, 3-step actionable plan tailored to the user's profile.
Return ONLY JSON: { "details": "..." } with the details string.

Tip:
${JSON.stringify(tip)}

Profile:
${JSON.stringify(profile || {})}
`;

    const content = await callOpenAIChat([{ role: 'user', content: prompt }], 400, 0.7);
    const parsed = safeParseJSON(content);
    const details = (parsed && parsed.details) ? parsed.details : content;
    return res.json({ ok: true, id: tipId, details });
  } catch (err) {
    console.error('expand-tip error:', err);
    return res.status(500).json({ ok: false, error: err.message || 'server error' });
  }
});

// health
app.get('/health', (req, res) => res.json({ ok: true, mock: MOCK_AI }));

app.listen(PORT, () => {
  console.log(`AI Wellness backend listening on http://localhost:${PORT} (MOCK_AI=${MOCK_AI})`);
});
