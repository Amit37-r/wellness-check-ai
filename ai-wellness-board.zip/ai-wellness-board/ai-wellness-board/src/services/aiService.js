// src/services/aiService.js
export async function generateTips(profile) {
  const res = await fetch('/api/generate-tips', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ profile })
  });
  if (!res.ok) {
    const t = await res.text();
    throw new Error(`generateTips failed: ${res.status} ${t}`);
  }
  const json = await res.json();
  console.debug('[aiService] generateTips ->', json);
  if (json.ok && Array.isArray(json.tips)) return json.tips;
  if (json.tips_raw) {
    try { return JSON.parse(json.tips_raw); } catch { return []; }
  }
  return [];
}

// frontend: src/services/aiService.js (expandTip)
export async function expandTip(tip, profile) {
  const res = await fetch('/api/expand-tip', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ tip, profile })
  });
  if (!res.ok) throw new Error(await res.text());
  const json = await res.json();
  // canonical return { id, details }
  return { id: json.id || tip.id, details: json.details || '' };
}
