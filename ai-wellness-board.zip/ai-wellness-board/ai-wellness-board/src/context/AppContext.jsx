import React, { createContext, useContext, useState, useEffect } from 'react';

const AppContext = createContext();

export function AppProvider({ children }) {
  const [profile, setProfile] = useState({ age: '', gender: '', goal: '' });
  const [favorites, setFavorites] = useState([]);

  useEffect(() => {
    const savedProfile = localStorage.getItem('profile');
    const savedFavs = localStorage.getItem('favorites');
    if (savedProfile) {
      try {
        setProfile(JSON.parse(savedProfile));
      } catch (err) {
        // ignore parse error
      }
    }
    if (savedFavs) {
      try {
        setFavorites(JSON.parse(savedFavs));
      } catch (err) {
        // ignore parse error
      }
    }
  }, []);

  useEffect(() => {
    try {
      localStorage.setItem('profile', JSON.stringify(profile));
    } catch (err) {
      // ignore
    }
  }, [profile]);

  useEffect(() => {
    try {
      localStorage.setItem('favorites', JSON.stringify(favorites));
    } catch (err) {
      // ignore
    }
  }, [favorites]);

  function toggleFavorite(tip) {
    setFavorites((prev) =>
      prev.some((x) => x.id === tip.id) ? prev.filter((x) => x.id !== tip.id) : [...prev, tip]
    );
  }

  return (
    <AppContext.Provider value={{ profile, setProfile, favorites, toggleFavorite }}>
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const ctx = useContext(AppContext);
  if (!ctx) {
    throw new Error('useApp must be used within AppProvider');
  }
  return ctx;
}
