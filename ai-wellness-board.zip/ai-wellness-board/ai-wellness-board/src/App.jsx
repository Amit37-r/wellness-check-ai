// src/App.jsx
import React, { useState, useEffect } from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { generateTips, expandTip } from './services/aiService';
import ProfileForm from './components/ProfileForm';
import TipCard from './components/TipCard';
import FavoritesList from './components/FavoritesList';

function InnerApp() {
  const { profile, favorites, toggleFavorite } = useApp();

  const [tips, setTips] = useState([]);
  const [loading, setLoading] = useState(false);

  const [expandedIds, setExpandedIds] = useState(new Set());
  const [loadingIds, setLoadingIds] = useState(new Set());
  const [detailsMap, setDetailsMap] = useState({}); // canonical: detailsMap[requestedId] = string

  // debug helpers on window so you can inspect state manually
  useEffect(() => {
    window.__debug_tips = tips;
    window.__debug_detailsMap = detailsMap;
    window.__debug_expanded = Array.from(expandedIds);
  }, [tips, detailsMap, expandedIds]);

  function ensureUniqueIds(arr) {
    const now = Date.now();
    return arr.map((t, idx) => {
      const { details, id, ...rest } = t || {};
      const finalId = id ?? `gen-${now}-${idx}`;
      return { id: finalId, ...rest };
    });
  }

  async function handleGenerate() {
    setLoading(true);
    try {
      const out = await generateTips(profile);
      const arr = Array.isArray(out) ? out : [];
      const normalized = ensureUniqueIds(arr.map((t) => {
        if (!t) return t;
        const { details, ...rest } = t;
        return rest;
      }));

      console.debug('[App] normalized tips ->', normalized);
      setTips(normalized);
      setDetailsMap({});
      setExpandedIds(new Set());
      setLoadingIds(new Set());
    } catch (err) {
      console.error('generate tips error', err);
      alert('Failed to fetch tips: ' + (err?.message || err));
    } finally {
      setLoading(false);
    }
  }

  async function handleToggleExpand(tip) {
  const id = tip?.id;
  if (!id) {
    console.warn('Missing tip id', tip);
    return;
  }

  // close if open
  if (expandedIds.has(id)) {
    setExpandedIds(prev => { const n = new Set(prev); n.delete(id); return n; });
    return;
  }

  // expand from cache if available
  if (detailsMap[id]) {
    setExpandedIds(prev => { const n = new Set(prev); n.add(id); return n; });
    console.debug('[App] expanded from cache for id', id);
    return;
  }

  // mark loading for requested id
  setLoadingIds(prev => { const n = new Set(prev); n.add(id); return n; });

  try {
    // Call backend to expand; expect { requestedId, returnedId, details } OR { id, details }
    const expandedRes = await expandTip(tip, profile);
    console.debug('[App] expandTip returned ->', expandedRes);

    // === HERE: store details under the ORIGINAL requested id (tip.id) ===
    const storageKey = tip.id; // always use the requested id as canonical key
    const details = expandedRes.details || expandedRes.detail || '';

    setDetailsMap(prev => ({ ...prev, [storageKey]: details }));
    setExpandedIds(prev => { const n = new Set(prev); n.add(storageKey); return n; });
    console.debug('[App] detailsMap updated for', storageKey);

  } catch (err) {
    console.error('expand error', err);
    alert('Failed to load details: ' + (err?.message || err));
  } finally {
    setLoadingIds(prev => { const n = new Set(prev); n.delete(id); return n; });
  }
}

     

    

  return (
    <div className="app">
      <h2>AI Wellness Board</h2>

      <ProfileForm onGenerate={handleGenerate} />

      {loading && <div className="small">Loading tips...</div>}

      <div className="grid" style={{ marginTop: 12 }}>
        {tips.map((t) => (
          <TipCard
            key={t.id}
            tip={t}
            isFav={favorites.some((x) => x.id === t.id)}
            isExpanded={expandedIds.has(t.id)}
            isLoading={loadingIds.has(t.id)}
            details={detailsMap[t.id]}
            onExpand={() => handleToggleExpand(t)}
            onToggleFav={() => toggleFavorite(t)}
          />
        ))}
      </div>

      <FavoritesList />
    </div>
  );
}

export default function App() {
  return (
    <AppProvider>
      <InnerApp />
    </AppProvider>
  );
}
