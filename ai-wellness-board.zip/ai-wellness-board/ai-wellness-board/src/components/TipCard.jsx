// src/components/TipCard.jsx
import React from 'react';

export default function TipCard({ tip, isFav, isExpanded, isLoading, details, onExpand, onToggleFav }) {
  return (
    <div className="card" style={{ flexDirection: 'column', alignItems: 'flex-start', minHeight: 140 }}>
      <div style={{ display: 'flex', width: '100%', alignItems: 'center', gap: 12 }}>
        <div style={{ fontSize: 28 }}>{tip?.icon || '✨'}</div>

        <div style={{ flex: 1 }}>
          <div className="tip-title">{tip?.title || 'Untitled'}</div>
          <div className="small">{tip?.summary || ''}</div>
        </div>

        <div style={{ display: 'flex', gap: 8 }}>
          <button
            className="btn"
            onClick={onExpand}
            disabled={!!isLoading}
            aria-pressed={!!isExpanded}
            title={isLoading ? 'Loading details...' : isExpanded ? 'Close details' : 'Open details'}
          >
            {isLoading ? 'Loading…' : isExpanded ? 'Close' : 'Open'}
          </button>

          <button className="btn" onClick={onToggleFav} aria-label={isFav ? 'Remove from favorites' : 'Save to favorites'}>
            {isFav ? 'Unsave' : 'Save'}
          </button>
        </div>
      </div>

      {isExpanded && details && (
        <div style={{ marginTop: 10, whiteSpace: 'pre-wrap' }} className="small">
          {details}
        </div>
      )}
    </div>
  );
}
