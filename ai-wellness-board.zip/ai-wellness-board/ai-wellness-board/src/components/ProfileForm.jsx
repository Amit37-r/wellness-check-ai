import React from 'react';
import { useApp } from '../context/AppContext';

export default function ProfileForm({ onGenerate }) {
  const { profile, setProfile } = useApp();

  return (
    <form className="card profile-form" onSubmit={(e) => { e.preventDefault(); onGenerate(); }}>
      <input
        placeholder="Age"
        value={profile.age}
        onChange={(e) => setProfile({ ...profile, age: e.target.value })}
      />
      <select value={profile.gender} onChange={(e) => setProfile({ ...profile, gender: e.target.value })}>
        <option value="">Gender</option>
        <option value="male">Male</option>
        <option value="female">Female</option>
        <option value="other">Other</option>
      </select>
      <input
        placeholder="Goal (e.g., weight loss)"
        value={profile.goal}
        onChange={(e) => setProfile({ ...profile, goal: e.target.value })}
      />
      <button className="btn btn-primary" type="submit">Generate Tips</button>
    </form>
  );
}
