import React from 'react';
import { useApp } from '../context/AppContext';

export default function FavoritesList() {
  const { favorites, toggleFavorite } = useApp();

  return (
    <div className="card" style={{ flexDirection: 'column' }}>
      <h4>Saved Favorites</h4>
      {favorites.length === 0 && <div className="small">No favorites yet.</div>}
      <div className="grid" style={{ marginTop: 8 }}>
        {favorites.map((f) => (
          <div key={f.id} className="card" style={{ flexDirection: 'row', alignItems: 'center' }}>
            <div style={{ fontSize: 20 }}>{f.icon}</div>
            <div style={{ marginLeft: 8, flex: 1 }}>
              <div>{f.title}</div>
              <div className="small">{f.summary}</div>
            </div>
            <button className="btn" onClick={() => toggleFavorite(f)}>Remove</button>
          </div>
        ))}
      </div>
    </div>
  );
}
