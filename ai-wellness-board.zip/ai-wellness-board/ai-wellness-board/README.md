 
 # 🧑‍💻 AI Wellness Tips App

This is a **React + Express full-stack app** that generates and expands **personalized wellness tips**.  
It uses the **OpenAI API** when available, and falls back to mock data if `MOCK_AI=true`.

---

##  Project Structure

```
.
├── ai-wellness-board/   # React (Vite) app
│   └── src/
│       ├── App.jsx
│       ├── components/
│       ├── services/
│       └── context/
└── server/     # Express backend
    └── index.js
```

---

##  Setup Instructions

### 1. Clone the repo
```bash
git clone <your-repo-url>
cd <your-repo-folder>
```

### 2. Install dependencies

Frontend:
```bash
cd frontend
npm install
```

Backend:
```bash
cd ../server
npm install
```

### 3. Environment variables

Create a file **`server/.env`**:

```env
# OpenAI key (get it from https://platform.openai.com/account/api-keys)
OPENAI_API_KEY=sk-xxxxxxxxxxxxxxxxxxxxxxxxxxxx

# Use mock responses? (true/false)
MOCK_AI=false

# Port for backend
PORT=5174
```

 

---

##  Running the App

### Start backend (Express)
```bash
cd server
npm run dev
```
Backend runs on **http://localhost:5174**

Test health check:
```bash
curl http://localhost:5174/health
# → {"ok":true,"mock":false}
```

### Start frontend (React + Vite)
Open a second terminal:
```bash
cd frontend
npm run dev
```
Frontend runs on **http://localhost:5173**

---

##  Testing APIs (optional)

### Generate tips
```bash
curl -X POST http://localhost:5174/api/generate-tips  -H "Content-Type: application/json"  -d '{"profile":{"age":28,"goal":"weight loss"}}'
```

### Expand a tip
```bash
curl -X POST http://localhost:5174/api/expand-tip  -H "Content-Type: application/json"  -d '{"tip":{"id":"tip-1","title":"Brisk walk"},"profile":{"age":28,"goal":"weight loss"}}'
```

---

## 🖥️ Using the App

1. Open frontend in your browser → [http://localhost:5173](http://localhost:5173)  
2. Fill your profile (age, gender, goal)  
3. Click **Generate Tips** → see personalized tips  
4. Click **Open** → view expanded details for that tip  
5. Click **Save/Unsave** → manage your favorites  

---

##  Features
- Profile form (age, gender, goal)  
- Generate personalized wellness tips  
- Expand tips into detailed 3-step plans  
- Save/unsave favorites  
- LocalStorage persistence  


  
